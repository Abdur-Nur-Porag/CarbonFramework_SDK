package {{PACKAGE_NAME}};
import {{PACKAGE_NAME}}.BaseBridge;
import {{PACKAGE_NAME}}.BridgeHandler;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.graphics.Point;
import android.view.Display;
import android.view.WindowMetrics;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * CoreBridges — Built-in bridge implementations
 *
 * Each static inner class handles one logical group of actions.
 * All are registered in BridgeHandler's constructor.
 *
 * ══════════════════════════════════════════════════════════════
 *  INCLUDED BRIDGES
 * ══════════════════════════════════════════════════════════════
 *
 *  SystemBridge    — killApp, openBrowser, deviceModel, osVersion,
 *                    keepScreenOn, vibrate,
 *                    enableScreenshotProtection, disableScreenshotProtection
 *  StorageBridge   — saveData, loadData
 *  UiBridge        — showToast, copyToClipboard, shareText,
 *                    hideStatusbar, showStatusbar, setStatusbarColor,
 *                    isDarkMode, getColorPrimary, getColorPrimaryDark,
 *                    showBelowStatusBar, getStatusBarHeight,
 *                    getNavigationBarHeight,
 *                    getScreenWidth, getScreenHeight,
 *                    getBatteryLevel, isNetworkAvailable,
 *                    getOrientation, setOrientation
 *  BackpressBridge — disableBackpress(bool) only. onBackpress() is JS-side
 *                    (see android_shim.js) — the persistent handler is
 *                    invoked directly by PreviewRender.onBackPressed().
 *  QuickJsBridge   — runQuickJS, readFile
 *
 * ══════════════════════════════════════════════════════════════
 *  HOW TO ADD MORE ACTIONS TO AN EXISTING BRIDGE
 * ══════════════════════════════════════════════════════════════
 *
 *  1. Add the action name to the ACTIONS set inside the bridge.
 *  2. Add a case in handleSync() (or handleAsync() / isAsync()).
 *  3. That's it — no changes needed elsewhere.
 *
 * ══════════════════════════════════════════════════════════════
 */
public final class CoreBridges {

    private CoreBridges() {}

    // ══════════════════════════════════════════════════════════════
    // 1. SYSTEM BRIDGE
    //    Actions: killApp, openExternalBrowser, getDeviceModel,
    //             getOSVersion, keepScreenOn, vibrate
    // ══════════════════════════════════════════════════════════════
    public static class SystemBridge extends BaseBridge {

        private static final Set<String> ACTIONS = new HashSet<>(Arrays.asList(
            "killApp", "openExternalBrowser", "getDeviceModel", "getOSVersion",
            "keepScreenOn", "vibrate",
            "checkPermission", "requestPermission",
            "enableScreenshotProtection", "disableScreenshotProtection"
            // ↑ ADD MORE SYSTEM ACTIONS HERE
        ));

        private final Activity activity;
        private final BridgeHandler bridge;

        public SystemBridge(Activity activity, BridgeHandler bridge) {
            this.activity = activity;
            this.bridge   = bridge;
        }

        @Override public boolean handles(String action) { return ACTIONS.contains(action); }

        @Override
        public String handleSync(String action, String payload) throws Exception {
            switch (action) {

                case "killApp":
                    activity.runOnUiThread(() -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
                            activity.finishAffinity();
                        else activity.finish();
                        System.exit(0);
                    });
                    return "OK";

                case "openExternalBrowser":
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(payload)));
                    return "OK";

                case "getDeviceModel":
                    return Build.MANUFACTURER + " " + Build.MODEL;

                case "getOSVersion":
                    return Build.VERSION.RELEASE;

                case "keepScreenOn":
                    boolean keepOn = Boolean.parseBoolean(payload);
                    activity.runOnUiThread(() -> {
                        if (keepOn) activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        else        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    });
                    return "OK";

                case "vibrate":
                    long duration = Long.parseLong(payload);
                    Vibrator v = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
                    if (v != null && v.hasVibrator()) v.vibrate(duration);
                    return "OK";

                case "checkPermission":
                    return String.valueOf(bridge.checkPermission(payload));

                // NOTE: requestPermission with callback lives in BackpressBridge pattern.
                // This sync version just fire-and-forget (no JS callback for result).
                case "requestPermission":
                    bridge.requestPermission(payload, null);
                    return "OK";

                // Blocks screenshots AND blanks the app preview in the
                // recent-apps switcher (same flag drives both on Android).
                case "enableScreenshotProtection":
                    activity.runOnUiThread(() ->
                        activity.getWindow().setFlags(
                            WindowManager.LayoutParams.FLAG_SECURE,
                            WindowManager.LayoutParams.FLAG_SECURE));
                    return "OK";

                case "disableScreenshotProtection":
                    activity.runOnUiThread(() ->
                        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE));
                    return "OK";

                default: return "UNKNOWN";
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 2. STORAGE BRIDGE
    //    Actions: saveData, loadData
    // ══════════════════════════════════════════════════════════════
    public static class StorageBridge extends BaseBridge {

        private static final Set<String> ACTIONS = new HashSet<>(Arrays.asList(
            "saveData", "loadData"
            // ↑ ADD MORE STORAGE ACTIONS HERE (e.g. "deleteData", "clearAll")
        ));

        private final SharedPreferences prefs;

        public StorageBridge(Activity activity) {
            this.prefs = activity.getSharedPreferences("WebAppPrefs", Context.MODE_PRIVATE);
        }

        @Override public boolean handles(String action) { return ACTIONS.contains(action); }

        @Override
        public String handleSync(String action, String payload) throws Exception {
            switch (action) {

                case "saveData":
                    JSONObject json = new JSONObject(payload);
                    prefs.edit().putString(json.getString("k"), json.getString("v")).apply();
                    return "OK";

                case "loadData":
                    return prefs.getString(payload, "");

                default: return "UNKNOWN";
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 3. UI BRIDGE
    //    Actions: showToast, copyToClipboard, shareText,
    //             hideStatusbar, showStatusbar, setStatusbarColor,
    //             isDarkMode, getColorPrimary, getColorPrimaryDark,
    //             showBelowStatusBar, getStatusBarHeight,
    //             getScreenWidth, getScreenHeight,
    //             getBatteryLevel, isNetworkAvailable
    // ══════════════════════════════════════════════════════════════
    public static class UiBridge extends BaseBridge {

        private static final Set<String> ACTIONS = new HashSet<>(Arrays.asList(
            "showToast", "copyToClipboard", "shareText",
            "hideStatusbar", "showStatusbar", "setStatusbarColor",
            "isDarkMode", "getColorPrimary", "getColorPrimaryDark",
            "showBelowStatusBar",
            "getStatusBarHeight", "getNavigationBarHeight",
            "getScreenWidth", "getScreenHeight",
            "getBatteryLevel", "isNetworkAvailable",
            "getOrientation", "setOrientation"
            // ↑ ADD MORE UI ACTIONS HERE
        ));

        private final Activity activity;
        private final BridgeHandler bridge;

        public UiBridge(Activity activity, BridgeHandler bridge) {
            this.activity = activity;
            this.bridge   = bridge;
        }

        @Override public boolean handles(String action) { return ACTIONS.contains(action); }

        @Override
        public String handleSync(String action, String payload) throws Exception {
            switch (action) {

                case "showToast":
                    activity.runOnUiThread(() ->
                        Toast.makeText(activity, payload, Toast.LENGTH_SHORT).show());
                    return "OK";

                case "copyToClipboard":
                    // ClipboardManager requires the main (UI) thread — accessing it on a
                    // background thread causes "Can't create handler … Looper.prepare()".
                    activity.runOnUiThread(() -> {
                        ClipboardManager cb = (ClipboardManager)
                                activity.getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cb != null) {
                            cb.setPrimaryClip(ClipData.newPlainText("Copied", payload));
                            Toast.makeText(activity, "Copied", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return "OK";

                case "shareText":
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, payload);
                    activity.startActivity(Intent.createChooser(share, "Share"));
                    return "OK";

                case "hideStatusbar":
                    activity.runOnUiThread(() ->
                        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN));
                    return "OK";

                case "showStatusbar":
                    activity.runOnUiThread(() ->
                        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN));
                    return "OK";

                case "setStatusbarColor":
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        activity.runOnUiThread(() -> {
                            try {
                                activity.getWindow().setStatusBarColor(
                                    android.graphics.Color.parseColor(payload));
                            } catch (Exception e) {
                                Log.e("UiBridge", "Bad color: " + payload);
                            }
                        });
                    }
                    return "OK";

                case "isDarkMode":
                    int flags = activity.getResources().getConfiguration().uiMode
                                & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
                    return String.valueOf(flags == android.content.res.Configuration.UI_MODE_NIGHT_YES);

                case "getColorPrimary":
                    return resolveThemeColor(androidx.appcompat.R.attr.colorPrimary);

                case "getColorPrimaryDark":
                    return resolveThemeColor(androidx.appcompat.R.attr.colorPrimaryDark);

                case "showBelowStatusBar":
                    // true  → WebView draws behind/over the status bar (edge-to-edge)
                    // false → WebView starts below the status bar (normal layout)
                    boolean below = Boolean.parseBoolean(payload);
                    activity.runOnUiThread(() -> {
                        if (below) {
                            // Draw content behind status bar
                            activity.getWindow().getDecorView().setSystemUiVisibility(
                                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
                        } else {
                            // Restore normal layout (status bar occupies its own space)
                            int uiFlags = activity.getWindow().getDecorView().getSystemUiVisibility();
                            uiFlags &= ~View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
                            uiFlags &= ~View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
                            activity.getWindow().getDecorView().setSystemUiVisibility(uiFlags);
                        }
                    });
                    return "OK";

                case "getStatusBarHeight": {
                    int resourceId = activity.getResources()
                        .getIdentifier("status_bar_height", "dimen", "android");
                    int px = (resourceId > 0)
                        ? activity.getResources().getDimensionPixelSize(resourceId)
                        : 0;
                    // Convert px → dp for JS convenience
                    float density = activity.getResources().getDisplayMetrics().density;
                    return String.valueOf(Math.round(px / density));
                }

                case "getNavigationBarHeight": {
                    // 0 if the device uses full gesture navigation with no
                    // reserved bar (still a valid, expected answer).
                    int resourceId = activity.getResources()
                        .getIdentifier("navigation_bar_height", "dimen", "android");
                    int px = (resourceId > 0)
                        ? activity.getResources().getDimensionPixelSize(resourceId)
                        : 0;
                    float density = activity.getResources().getDisplayMetrics().density;
                    return String.valueOf(Math.round(px / density));
                }

                case "getScreenWidth":
                    return String.valueOf(getScreenSize().x);

                case "getScreenHeight":
                    return String.valueOf(getScreenSize().y);

                case "getBatteryLevel": {
                    // API 21+: query BatteryManager directly — instant, reliable,
                    // no broadcast-registration edge cases.
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        BatteryManager bm =
                            (BatteryManager) activity.getSystemService(Context.BATTERY_SERVICE);
                        if (bm != null) {
                            int capacity = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                            if (capacity >= 0) return String.valueOf(capacity);
                        }
                    }
                    // Pre-21 fallback: sticky broadcast (always available, all API levels).
                    Intent batteryIntent = activity.registerReceiver(null,
                        new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                    if (batteryIntent == null) return "-1";
                    int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    if (level < 0 || scale <= 0) return "-1";
                    return String.valueOf((int) ((level / (float) scale) * 100));
                }

                case "isNetworkAvailable": {
                    ConnectivityManager cm = (ConnectivityManager)
                        activity.getSystemService(Context.CONNECTIVITY_SERVICE);
                    if (cm == null) return "false";

                    // API 23+: NetworkCapabilities correctly reflects VPNs, multiple
                    // simultaneous networks, and actual internet reachability —
                    // getActiveNetworkInfo() is deprecated since API 29 and can
                    // misreport on those cases on newer devices.
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Network network = cm.getActiveNetwork();
                        if (network == null) return "false";
                        NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                        boolean connected = caps != null
                            && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                            && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                        return String.valueOf(connected);
                    }

                    // Pre-23 fallback.
                    @SuppressWarnings("deprecation")
                    NetworkInfo ni = cm.getActiveNetworkInfo();
                    return String.valueOf(ni != null && ni.isConnected());
                }

                case "getOrientation": {
                    int orientation = activity.getResources().getConfiguration().orientation;
                    return (orientation == Configuration.ORIENTATION_LANDSCAPE)
                        ? "landscape" : "portrait";
                }

                // Lock or unlock the screen orientation.
                // payload: "portrait" | "landscape" | "reverse_portrait" |
                //          "reverse_landscape" | "sensor_portrait" | "sensor_landscape" |
                //          "sensor" | "full_sensor" | "auto" (== "unspecified") | "locked"
                case "setOrientation": {
                    final int mode = resolveOrientation(payload);
                    activity.runOnUiThread(() -> activity.setRequestedOrientation(mode));
                    return "OK";
                }

                default: return "UNKNOWN";
            }
        }

        /**
         * Returns physical screen size in pixels.
         * API 30+: WindowMetrics — correct on foldables, split-screen, and
         * multi-window, where getDefaultDisplay() reports stale/wrong bounds.
         * Pre-30: falls back to the classic Display API.
         */
        private Point getScreenSize() {
            Point size = new Point();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                WindowMetrics wm = activity.getWindowManager().getCurrentWindowMetrics();
                android.graphics.Rect bounds = wm.getBounds();
                size.x = bounds.width();
                size.y = bounds.height();
            } else {
                @SuppressWarnings("deprecation")
                Display display = activity.getWindowManager().getDefaultDisplay();
                android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
                display.getMetrics(dm);
                size.x = dm.widthPixels;
                size.y = dm.heightPixels;
            }
            return size;
        }

        private int resolveOrientation(String name) {
            if (name == null) return ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
            switch (name.toLowerCase()) {
                case "portrait":           return ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                case "landscape":          return ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                case "reverse_portrait":   return ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
                case "reverse_landscape":  return ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
                case "sensor_portrait":    return ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
                case "sensor_landscape":   return ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
                case "sensor":             return ActivityInfo.SCREEN_ORIENTATION_SENSOR;
                case "full_sensor":        return ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR;
                case "locked":
                    // SCREEN_ORIENTATION_LOCKED requires API 18 — fall back to
                    // whatever the device is currently showing on older devices.
                    if (Build.VERSION.SDK_INT >= 18) return ActivityInfo.SCREEN_ORIENTATION_LOCKED;
                    return (activity.getResources().getConfiguration().orientation
                            == Configuration.ORIENTATION_LANDSCAPE)
                        ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                case "auto":
                case "unspecified":
                default:                   return ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
            }
        }

        private String resolveThemeColor(int attr) {
            android.util.TypedValue tv = new android.util.TypedValue();
            activity.getTheme().resolveAttribute(attr, tv, true);
            try { return String.format("#%06X", 0xFFFFFF & tv.data); }
            catch (Exception e) { return "#FFFFFF"; }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 4. BACKPRESS BRIDGE
    // ══════════════════════════════════════════════════════════════
    /**
     * BACKPRESS — exactly 2 JS-facing APIs (see android_shim.js):
     *
     *   Android.disableBackpress(true/false)
     *   Android.onBackpress(() => { ... })
     *
     * Design: this Java bridge only owns the ON/OFF flag. It does NOT track
     * or resolve any JS callback — onBackpress() is handled entirely on the
     * JS side (bridge_core.js stores the handler; android_shim.js registers
     * it). PreviewRender.onBackPressed() calls
     * window._CarbonInternal.triggerBackpress() directly via evaluateJavascript
     * on every single back press while the flag below is true, so the
     * handler fires repeatably — not just once — and the app never exits
     * from back presses until disableBackpress(false) or Android.killApp().
     */
    public static class BackpressBridge extends BaseBridge {

        private static final Set<String> ACTIONS = new HashSet<>(Arrays.asList(
            "disableBackpress"
        ));

        private final BridgeHandler bridge;

        public BackpressBridge(Activity activity, BridgeHandler bridge) {
            this.bridge = bridge;
        }

        @Override public boolean handles(String action) { return ACTIONS.contains(action); }

        @Override
        public String handleSync(String action, String payload) {
            if ("disableBackpress".equals(action)) {
                bridge.setBackpressDisabled(Boolean.parseBoolean(payload));
                return "OK";
            }
            return "UNKNOWN";
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 5. QUICKJS / FILE BRIDGE
    //    Actions: runQuickJS, readFile
    // ══════════════════════════════════════════════════════════════
    public static class QuickJsBridge extends BaseBridge {

        private static final Set<String> ASYNC_ACTIONS = new HashSet<>(Arrays.asList(
            "runQuickJS", "readFile"
        ));

        private final BridgeHandler bridge;

        public QuickJsBridge(BridgeHandler bridge) {
            this.bridge = bridge;
        }

        @Override public boolean handles(String action) { return ASYNC_ACTIONS.contains(action); }
        @Override public boolean isAsync(String action)  { return true; }

        @Override
        public void handleAsync(String action, String payload, Callback callback) {
            try {
                switch (action) {

                    case "runQuickJS":
                        String result = bridge.evaluateQuickJS(payload);
                        if (result.startsWith("ERROR:")) callback.reject(result);
                        else callback.resolve(result);
                        break;

                    case "readFile":
                        String content = bridge.readFileFromAsset(payload);
                        if ("ERROR".equals(content))
                            callback.reject("FileNotFound: " + payload);
                        else
                            callback.resolve(content);
                        break;

                    default:
                        callback.reject("UNKNOWN_ACTION:" + action);
                }
            } catch (Exception e) {
                callback.reject(e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
    }
}