package {{PACKAGE_NAME}};
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.reflect.Method;
import android.webkit.ConsoleMessage;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import {{PACKAGE_NAME}}.CoreBridges;
import java.util.ArrayList;
import java.util.List;

/**
 * MainRender — High Performance Web Engine
 *
 * Architecture:
 *  - Uses prompt-based async bridging (onJsPrompt) for zero-blocking JS execution.
 *  - All native actions are routed through BridgeHandler which delegates to CoreBridges/.
 *  - JS shim files live in assets/base/ and are injected after every page load.
 */
public class MainRender {

    private final WebView webView;
    private final Activity activity;
    private BridgeHandler bridgeHandler;

    public ValueCallback<Uri[]> uploadMessageAboveL;

    // Tracks first load — prevents visibility flash on app resume
    private boolean hasPageLoaded = false;

    // Static screenshot shown over the WebView while it is paused/resuming,
    // so the user never sees the underlying surface teardown/recompose flash.
    // Also reused (with a flat color instead of a bitmap) as the cold-start
    // cover — see COLD-START COVER section below.
    private ImageView freezeFrameOverlay;
    private ViewTreeObserver.OnPreDrawListener revealListener;

    // Reused across pause/resume cycles so we're not allocating a fresh
    // bitmap on every single background/foreground event — see synchronousFreeze().
    private Bitmap cachedSnapshotBuffer;

    // Cancelled as soon as a real reveal happens — see COLD-START COVER section.
    private Runnable coldStartSafetyRunnable;

    // Cached per-process; device tier doesn't change at runtime.
    private static Boolean sIsLowEndDeviceCache;

    // Reflection handle for PixelCopy.request(View, Bitmap, OnPixelCopyFinishedListener, Handler),
    // which only exists in API 31+ android.jar stubs. Looked up via reflection
    // (see tryPixelCopyViewCapture()) instead of called directly, because some
    // toolchains (e.g. older bundled SDKs) compile against a pre-31 stub where
    // that overload doesn't exist — a direct reference would fail to compile
    // there even behind a runtime SDK_INT check, since Java resolves method
    // signatures at compile time against the stub jar, not the real device OS.
    private static Method sPixelCopyRequestViewMethod;
    private static boolean sPixelCopyViewChecked = false;

    private static final String TAG      = "WebEngineCore";
    /** Set to false before exporting/releasing your app. True = JS logs visible in adb logcat. */
    private static final boolean DEBUG_LOGS = false;
    private static final String BRIDGE_PREFIX = "bridge_req:";

    // ── Tunables for the pause/resume + cold-start cover system ──
    // Centralized here so they're easy to tune per-app without hunting
    // through method bodies.
    //
    // Deliberately NOT tunable here: a spatial resolution downscale for the
    // freeze-frame snapshot. That was tried and removed — a downscaled
    // bitmap stretched back up to full size blurs fine detail like button
    // text noticeably compared to the live WebView, and the blur-vs-sharp
    // difference reads as a visible "bounce"/pop on text right when the
    // overlay swaps in or out. Bitmap.Config (RGB_565 vs ARGB_8888) is still
    // tiered by device in synchronousFreeze() since that only reduces color
    // depth, not spatial resolution, so it doesn't introduce that blur.
    private static final int   REVEAL_FRAMES_LOW_END         = 4;    // low-end GPUs / busy compositor threads need more real vsyncs to catch up
    private static final int   REVEAL_FRAMES_FAST             = 2;    // capable devices catch up almost immediately — don't hold the cover longer than needed
    private static final long  COLD_START_SAFETY_TIMEOUT_MS  = 6000; // absolute ceiling so a broken/slow load never leaves the user stuck on black

    public MainRender(Activity activity, WebView webView) {
        this(activity, webView, false);
    }

    /**
     * @param restoredAfterProcessDeath true when this instance is being created
     *        because Android killed the app's process while it was in the
     *        background (commonly from memory pressure with many other apps
     *        running) and is now recreating the Activity from Recents. Pass
     *        the result of (savedInstanceState != null && it's a fresh
     *        process) from MainActivity — see MainActivity for the detection
     *        logic. When true, a black cold-start cover is shown immediately
     *        instead of the normal bitmap freeze-frame (which needs a live
     *        process to have taken the screenshot from — see COLD-START COVER
     *        section below).
     */
    public MainRender(Activity activity, WebView webView, boolean restoredAfterProcessDeath) {
        this.activity = activity;
        this.webView  = webView;

        // Prevent white flash on boot
        this.webView.setVisibility(View.INVISIBLE);
        this.webView.setBackgroundColor(Color.TRANSPARENT);

        if (restoredAfterProcessDeath) {
            showColdStartCover();
        }

        this.initializeEngine();
    }

    // ─────────────────────────────────────────────────────────────
    // ENGINE BOOT
    // ─────────────────────────────────────────────────────────────

    private void initializeEngine() {
        Log.d(TAG, "Initializing Secure Engine...");
        this.applyHighPerformanceSettings();
        this.attachNativeBridge();
        this.configureChromeClient();
        this.configureWebViewClient();
        this.configureDownloadManager();
        this.beginLoading();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void applyHighPerformanceSettings() {
        WebSettings s = webView.getSettings();

        // ── Core JS & Storage ──
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);

        // Note: intentionally NOT forcing View.LAYER_TYPE_HARDWARE here.
        // Wrapping the WebView in an extra composited layer causes its cached
        // bitmap to be invalidated when the app is backgrounded, which is what
        // produced the blank flash / re-render on resume (home button -> reopen).
        // The window is already hardware-accelerated by default, so WebView
        // still renders on the GPU — this just removes the redundant layer.

        // ── Network / Cache Strategy ──
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        // ── Security ──
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(true);
        }
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);

        // ── Viewport ──
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        // ── Media ──
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadsImagesAutomatically(true);

        // ── UI: no scroll decorations, no overscroll bounce ──
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        // ── Transparent background avoids a white flash while the page paints ──
        webView.setBackgroundColor(Color.TRANSPARENT);
    }

    private void attachNativeBridge() {
        this.bridgeHandler = new BridgeHandler(activity);
    }

    // ─────────────────────────────────────────────────────────────
    // CHROME CLIENT  (handles JS dialogs, file chooser, permissions)
    // ─────────────────────────────────────────────────────────────

    private void configureChromeClient() {
        webView.setWebChromeClient(new WebChromeClient() {

            // ── Secure async message interceptor ──────────────────────
            @Override
            public boolean onJsPrompt(WebView view, String url, String message,
                                      String defaultValue, JsPromptResult result) {
                if (message != null && message.startsWith(BRIDGE_PREFIX)) {
                    try {
                        // Format:  bridge_req:<REQ_ID>:<ACTION>
                        String[] parts = message.split(":", 3);
                        if (parts.length < 3) {
                            result.confirm("ERROR:MalformedRequest");
                            return true;
                        }
                        String reqId  = parts[1];
                        String action = parts[2];

                        if ("STOP_TASK".equals(action)) {
                            bridgeHandler.stopTask(defaultValue);
                            result.confirm("STOPPED");
                        } else {
                            bridgeHandler.executeAsync(action, defaultValue, reqId, MainRender.this);
                            result.confirm("PENDING");
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Bridge error: ", e);
                        result.confirm("ERROR:" + e.getMessage());
                    }
                    return true;
                }
                return super.onJsPrompt(view, url, message, defaultValue, result);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                // Only log to logcat in debug builds — prevents state leaking via adb logcat
                if (DEBUG_LOGS) {
                    Log.d(TAG, String.format("JS [%s] %s  (line %d)",
                            cm.messageLevel().name(), cm.message(), cm.lineNumber()));
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                activity.runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        // Only grant WebRTC resources the app already holds at the OS level.
                        // Blind grant would let a page silently activate camera/mic.
                        List<String> toGrant = new ArrayList<>();
                        for (String res : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) {
                                if (ContextCompat.checkSelfPermission(activity,
                                        Manifest.permission.CAMERA)
                                        == PackageManager.PERMISSION_GRANTED)
                                    toGrant.add(res);
                            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) {
                                if (ContextCompat.checkSelfPermission(activity,
                                        Manifest.permission.RECORD_AUDIO)
                                        == PackageManager.PERMISSION_GRANTED)
                                    toGrant.add(res);
                            }
                        }
                        if (!toGrant.isEmpty())
                            request.grant(toGrant.toArray(new String[0]));
                        else
                            request.deny();
                    } else {
                        request.deny();
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> cb,
                                             FileChooserParams fcp) {
                if (uploadMessageAboveL != null) uploadMessageAboveL.onReceiveValue(null);
                uploadMessageAboveL = cb;
                try {
                    activity.startActivityForResult(fcp.createIntent(), 100);
                } catch (Exception e) {
                    uploadMessageAboveL = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
                result.confirm();
                return true;
            }
        });
    }

    // ─────────────────────────────────────────────────────────────
    // WEB VIEW CLIENT  (page lifecycle, URL routing, error page)
    // ─────────────────────────────────────────────────────────────

    private void configureWebViewClient() {
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Only run first-load setup once — skip on resume redraws
                if (!hasPageLoaded) {
                    hasPageLoaded = true;
                    view.setVisibility(View.VISIBLE);
                    injectCssNormalization();
                    // If this load followed a restored cold-start freeze-frame
                    // (process was killed in background), swap it out for the
                    // real page only once the real page has actually redrawn.
                    revealWhenRedrawn();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // System intents — hand off to Android and block from WebView
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("intent:")) {
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        Log.e(TAG, "Intent routing failed: " + url);
                    }
                    return true;
                }
                // Allow only local asset pages — block ALL external http/https URLs.
                // This prevents malicious redirects or injected links from loading
                // arbitrary sites inside the WebView with full bridge access.
                if (url.startsWith("file:///android_asset/")) {
                    return false; // allow
                }
                Log.w(TAG, "Blocked external URL: " + url);
                return true; // block everything else
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()) {
                    String html = "<html><body style='padding:50px;text-align:center;"
                            + "font-family:sans-serif;color:#333'>"
                            + "<h2>Engine Offline</h2><p>Check configuration or assets.</p>"
                            + "</body></html>";
                    view.loadData(html, "text/html", "UTF-8");
                }
            }
        });
    }

    private void configureDownloadManager() {
        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e) {
                Log.e(TAG, "Download intent failed", e);
            }
        });
    }

    // ─────────────────────────────────────────────────────────────
    // SCRIPT INJECTION
    // ─────────────────────────────────────────────────────────────

    private void injectCssNormalization() {
        StringBuilder css = new StringBuilder();
        css.append("*{-webkit-tap-highlight-color:transparent;outline:none;}");

        

        String script =
            "javascript:(function(){" +
            "var s=document.createElement('style');s.type='text/css';" +
            "s.appendChild(document.createTextNode('" + css.toString().replace("'", "\\'") + "'));" +
            "document.head.appendChild(s);})()";

        webView.evaluateJavascript(script, null);
    }


    // ─────────────────────────────────────────────────────────────
    // PUBLIC API — called by BridgeHandler / bridges
    // ─────────────────────────────────────────────────────────────

    /**
     * Resolves a JS Promise by calling window._CarbonInternal.onReply.
     * All string data is safely escaped to prevent template-literal crashes.
     */
    public void completeRequest(String id, String data, boolean isError) {
        activity.runOnUiThread(() -> {
            String safe = (data == null) ? "" : data
                    .replace("\\", "\\\\")
                    .replace("`",  "\\`")
                    .replace("$",  "\\$");

            String script = String.format(
                "if(window._CarbonInternal){window._CarbonInternal.onReply('%s',`%s`,%b);}",
                id, safe, isError);

            webView.evaluateJavascript(script, null);
        });
    }

    public void evaluateJavascript(String script) {
        activity.runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    // ─────────────────────────────────────────────────────────────
    // LIFECYCLE DELEGATION  (call from MainActivity)
    // ─────────────────────────────────────────────────────────────

    public void beginLoading() {
        webView.loadUrl("file:///android_asset/index.html");
    }

    public void clearSystemCache() {
        webView.clearCache(true);
        webView.clearHistory();
        webView.clearFormData();
    }

    public void onPause() {
        // Snapshot the current frame BEFORE onPause() tears anything down,
        // and cover the WebView with it. This is what actually hides the
        // native WebView surface teardown/recompose flash on the way back —
        // the user is looking at a plain static bitmap during the vulnerable
        // window instead of the live (glitching) surface.
        //
        // This only covers the "process survives" case (no memory kill) — see
        // the COLD-START COVER section further down for the memory-kill case,
        // which is handled separately at construction time since there's no
        // live frame left to snapshot by the time that scenario happens.
        freezeCurrentFrame();
        webView.onPause();
        webView.pauseTimers();
    }

    public void onResume() {
        webView.onResume();
        webView.resumeTimers();
        // onResume() also fires as a normal part of initial app startup, not
        // just when returning from background. If no page has actually
        // finished loading yet in this process (hasPageLoaded == false), a
        // reveal here would race ahead of the real page load and expose the
        // still-loading (invisible) WebView underneath — visible as content
        // briefly appearing then vanishing before the real page shows up.
        // onPageFinished() alone is responsible for the reveal until then.
        if (hasPageLoaded) {
            revealWhenRedrawn();
        }
    }

    // ─────────────────────────────────────────────────────────────
    // RESUME FLICKER FIX  (process stays alive — simple background/foreground)
    //
    // Android tears down / recomposites a hardware-accelerated WebView's
    // rendering surface when the app is backgrounded (this is an OS/Chromium-
    // level behavior, not something a WebView setting controls). The result
    // is a one-or-two-frame blank/flash the instant the app comes back to the
    // foreground, before the surface repaints. Native views don't suffer this
    // because they don't own a separate composited surface the way WebView
    // does.
    //
    // Fix: cover the WebView with a static screenshot of itself right before
    // it pauses, and only remove that cover once the WebView has actually
    // redrawn after resuming. Nothing visibly "redraws" during the gap
    // because the user is looking at a frozen bitmap, not the live surface.
    //
    // This only works when the process survives the whole trip (home button,
    // switching apps briefly, etc.) — there's a live WebView to screenshot
    // from. When the OS has actually killed the process, there's nothing left
    // to screenshot; see the separate COLD-START COVER section further down
    // for that case.
    //
    // Performance notes (capture must be fast, and the cover must not outstay
    // its welcome once real content is ready):
    //  - Capture prefers PixelCopy on capable devices (API 31+, non-low-end):
    //    it's hardware-accelerated and asynchronous, so it doesn't block the
    //    UI thread with a synchronous view.draw(canvas) call on the exact
    //    frame we're trying to back out of gracefully.
    //  - Low-end devices skip PixelCopy (the extra Handler round-trip isn't
    //    worth it there) and instead draw synchronously into a reused bitmap
    //    buffer at full resolution — avoids repeat GC pressure across cycles
    //    without the visible text/detail blur a spatial downscale would add
    //    (see the tunables block above for why resolution itself isn't
    //    reduced). Bitmap.Config drops to RGB_565 there instead, which saves
    //    memory via color depth rather than resolution.
    //  - The cover is pulled away after waiting for several real animation
    //    frames (Choreographer-driven), not a fixed millisecond guess. A
    //    fixed delay that's long enough on an idle device isn't long enough
    //    when many other background processes are competing for the CPU/GPU.
    //    The number of frames waited is itself tuned by device tier — fast
    //    devices get released in as few real frames as it takes, instead of
    //    being held behind a margin that's only needed on slower hardware.
    // ─────────────────────────────────────────────────────────────

    private boolean isLowEndDevice() {
        if (sIsLowEndDeviceCache != null) return sIsLowEndDeviceCache;
        boolean lowEnd = false;
        try {
            ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                lowEnd = am.isLowRamDevice();
                if (!lowEnd) {
                    ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
                    am.getMemoryInfo(info);
                    // isLowRamDevice() is a conservative OS/OEM flag that many
                    // budget devices still don't set — back it up with an
                    // actual total-RAM check so real low-end hardware isn't missed.
                    lowEnd = info.totalMem > 0 && info.totalMem < 2_500L * 1024 * 1024;
                }
            }
        } catch (Exception e) {
            // Can't tell from ActivityManager — fall through to the core-count check below.
        }
        if (!lowEnd) {
            lowEnd = Runtime.getRuntime().availableProcessors() <= 4;
        }
        sIsLowEndDeviceCache = lowEnd;
        return lowEnd;
    }

    private void ensureOverlay() {
        if (freezeFrameOverlay != null) return;
        freezeFrameOverlay = new ImageView(activity);
        freezeFrameOverlay.setScaleType(ImageView.ScaleType.FIT_XY);
        // Starts as MATCH_PARENT so there's never a gap before the WebView has
        // been through its first layout pass (e.g. the very first cold-start
        // cover, shown before layout has happened at all). syncOverlayToWebViewBounds()
        // below narrows this down to the WebView's exact real bounds as soon
        // as they're known — see that method for why this matters.
        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        // Adds directly on top of the whole window content, regardless of
        // what layout the WebView itself sits inside.
        activity.getWindow().addContentView(freezeFrameOverlay, lp);
    }

    /**
     * Resizes and repositions the overlay to exactly match the WebView's real
     * on-screen rectangle, instead of leaving it at MATCH_PARENT (the whole window).
     *
     * The overlay has to be added to the window's decor content view (see
     * ensureOverlay()) so it can sit on top of the WebView no matter what
     * layout the WebView itself lives inside — but that decor content view is
     * NOT necessarily the same size or position as the WebView. If there's a
     * header/toolbar above the WebView, or the window has status/nav-bar
     * insets, MATCH_PARENT covers a different rectangle than the WebView
     * actually occupies. The bitmap shown on the overlay is a screenshot of
     * just the WebView, stretched to fill whatever rectangle the overlay
     * covers — so if that rectangle doesn't match, the content visibly snaps
     * to a different size/position the instant the overlay is swapped in or
     * out relative to the live WebView underneath. That's the small "jump"
     * on home-button press and reopen.
     */
    private void syncOverlayToWebViewBounds() {
        if (freezeFrameOverlay == null) return;
        int w = webView.getWidth();
        int h = webView.getHeight();
        if (w <= 0 || h <= 0) return; // not laid out yet — leave overlay as-is for now

        View overlayParent = (View) freezeFrameOverlay.getParent();
        if (overlayParent == null) return;

        int[] webViewLoc = new int[2];
        webView.getLocationInWindow(webViewLoc);
        int[] parentLoc = new int[2];
        overlayParent.getLocationInWindow(parentLoc);

        freezeFrameOverlay.setX(webViewLoc[0] - parentLoc[0]);
        freezeFrameOverlay.setY(webViewLoc[1] - parentLoc[1]);

        ViewGroup.LayoutParams lp = freezeFrameOverlay.getLayoutParams();
        if (lp.width != w || lp.height != h) {
            lp.width = w;
            lp.height = h;
            freezeFrameOverlay.setLayoutParams(lp);
        }
    }

    private void freezeCurrentFrame() {
        if (!hasPageLoaded) return; // nothing meaningful painted yet — skip
        final int viewW = webView.getWidth();
        final int viewH = webView.getHeight();
        if (viewW <= 0 || viewH <= 0) return;

        boolean lowEnd = isLowEndDevice();

        // Async hardware-accelerated capture — doesn't block the UI thread.
        // Only attempted on capable devices; falls through to the synchronous
        // path below on low-end hardware or wherever it isn't available.
        if (!lowEnd && tryPixelCopyViewCapture(viewW, viewH)) {
            return; // capture is in flight; applySnapshotToOverlay() runs async
        }
        synchronousFreeze(viewW, viewH);
    }

    /**
     * Attempts an async PixelCopy capture of the WebView via reflection,
     * since PixelCopy.request(View, ...) only exists in API 31+ android.jar
     * stubs and some build toolchains compile against an older one (a direct
     * call would then fail to compile even behind a runtime SDK check). Looks
     * the method up once per process and reuses the Method handle after that.
     *
     * @return true if a capture was actually kicked off (result will land
     *         asynchronously via applySnapshotToOverlay() or a fallback to
     *         synchronousFreeze()); false if the caller should capture
     *         synchronously right now instead.
     */
    private boolean tryPixelCopyViewCapture(int viewW, int viewH) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        try {
            if (!sPixelCopyViewChecked) {
                sPixelCopyViewChecked = true;
                for (Method m : PixelCopy.class.getMethods()) {
                    // Match the parameter type EXACTLY against View.class — not
                    // isAssignableFrom — because the older SurfaceView-based
                    // overload's first parameter (SurfaceView) is *also*
                    // assignable to View, and isAssignableFrom would wrongly
                    // match that one too depending on getMethods() ordering.
                    if ("request".equals(m.getName())
                            && m.getParameterTypes().length == 4
                            && View.class.equals(m.getParameterTypes()[0])) {
                        sPixelCopyRequestViewMethod = m;
                        break;
                    }
                }
            }
            if (sPixelCopyRequestViewMethod == null) return false; // not available on this device/runtime

            final Bitmap dest = Bitmap.createBitmap(viewW, viewH, Bitmap.Config.ARGB_8888);
            ensureOverlay();
            Handler h = webView.getHandler() != null
                    ? webView.getHandler() : new Handler(Looper.getMainLooper());
            PixelCopy.OnPixelCopyFinishedListener listener = copyResult -> {
                if (copyResult == PixelCopy.SUCCESS) {
                    applySnapshotToOverlay(dest);
                } else {
                    // Fall back so the cover still appears even if the async path failed.
                    synchronousFreeze(viewW, viewH);
                }
            };
            sPixelCopyRequestViewMethod.invoke(null, webView, dest, listener, h);
            return true;
        } catch (Throwable t) {
            // Reflection failure, security restriction, or the call itself
            // throwing — any of these just mean "not available here".
            Log.w(TAG, "PixelCopy(view) capture unavailable, falling back: " + t.getMessage());
            return false;
        }
    }

    private void synchronousFreeze(int viewW, int viewH) {
        try {
            boolean lowEnd = isLowEndDevice();
            // Always capture at full resolution — no spatial downscaling.
            // A downscaled bitmap stretched back up via FIT_XY looks fine on
            // solid colors, but visibly blurs fine detail like button text,
            // hairline borders, and icons. Because the overlay swaps in and
            // out against the live (crisp) WebView, that blur-vs-sharp
            // difference reads as a distracting "bounce"/pop specifically on
            // text right at the swap — worse than the downscale was meant to
            // fix. Bitmap.Config is still tiered by device (RGB_565 on
            // low-end) since that only reduces color depth, not spatial
            // resolution, so it doesn't blur edges the same way.
            Bitmap.Config config = lowEnd ? Bitmap.Config.RGB_565 : Bitmap.Config.ARGB_8888;

            // Reuse one buffer across pause/resume cycles instead of allocating
            // a fresh bitmap every time — the difference that actually shows up
            // as jank on low-memory devices is repeat GC pressure, not the draw itself.
            if (cachedSnapshotBuffer == null || cachedSnapshotBuffer.isRecycled()
                    || cachedSnapshotBuffer.getWidth() != viewW || cachedSnapshotBuffer.getHeight() != viewH
                    || cachedSnapshotBuffer.getConfig() != config) {
                if (cachedSnapshotBuffer != null && !cachedSnapshotBuffer.isRecycled()) {
                    cachedSnapshotBuffer.recycle();
                }
                cachedSnapshotBuffer = Bitmap.createBitmap(viewW, viewH, config);
            }
            Canvas canvas = new Canvas(cachedSnapshotBuffer);
            webView.draw(canvas);

            applySnapshotToOverlay(cachedSnapshotBuffer);
        } catch (Exception e) {
            // Snapshot failed (e.g. low memory) — safe to just skip the cover;
            // worst case the original flicker briefly reappears this one time.
            Log.w(TAG, "Freeze-frame snapshot skipped: " + e.getMessage());
        }
    }

    private void applySnapshotToOverlay(Bitmap bitmap) {
        ensureOverlay();
        syncOverlayToWebViewBounds();
        freezeFrameOverlay.setBackgroundColor(Color.TRANSPARENT);
        freezeFrameOverlay.setImageBitmap(bitmap);
        freezeFrameOverlay.setVisibility(View.VISIBLE);
        freezeFrameOverlay.bringToFront();
    }

    private void revealWhenRedrawn() {
        if (freezeFrameOverlay == null || freezeFrameOverlay.getVisibility() != View.VISIBLE) return;

        // A real reveal path is now underway — the cold-start safety net (if
        // one was scheduled) is no longer needed.
        cancelColdStartSafetyReveal();

        if (revealListener != null) {
            webView.getViewTreeObserver().removeOnPreDrawListener(revealListener);
        }
        // Wait for the WebView's own next real draw pass before pulling the
        // cover away, instead of guessing with a fixed delay.
        revealListener = () -> {
            webView.getViewTreeObserver().removeOnPreDrawListener(revealListener);
            revealListener = null;
            // Then ride out a few more real vsync frames — under system load
            // Chromium's compositor thread can still lag a step or two behind
            // the Android View traversal that just fired this callback. The
            // frame count is tuned by device tier so capable hardware is
            // released as soon as it actually is caught up.
            waitFramesThenReveal(isLowEndDevice() ? REVEAL_FRAMES_LOW_END : REVEAL_FRAMES_FAST);
            return true;
        };
        webView.getViewTreeObserver().addOnPreDrawListener(revealListener);
        webView.invalidate();
    }

    private void waitFramesThenReveal(int framesRemaining) {
        if (framesRemaining <= 0) {
            if (freezeFrameOverlay != null) freezeFrameOverlay.setVisibility(View.GONE);
            return;
        }
        webView.postOnAnimation(() -> waitFramesThenReveal(framesRemaining - 1));
    }

    // ─────────────────────────────────────────────────────────────
    // COLD-START COVER  (process killed in background, restored from Recents)
    //
    // This is a different failure mode than the pause/resume flicker above.
    // There, the process stays alive the whole time, so there's always a live
    // frame to screenshot and cover with. Here, Android has killed the process
    // entirely — typically because many other apps were competing for memory
    // in the background — and is now recreating the Activity fresh when the
    // user taps it in Recents. There is no live WebView and no bitmap left in
    // memory to freeze; everything from the previous process is gone.
    //
    // Left alone, the user sees the system's own stale Recents task-snapshot
    // get replaced by our fresh (blank/invisible) WebView the instant the
    // Activity is created, which reads as a flicker because the two don't
    // match. Instead, we cover the entire window with a flat black screen
    // from the very first frame of the new process — before the WebView has
    // shown anything — and only lift it once the restored page has actually
    // finished loading AND redrawn (reusing the exact same revealWhenRedrawn()
    // path used for pause/resume, triggered from onPageFinished()). In
    // practice this covers the page for roughly 3-4 seconds on a typical
    // device while it reloads — a short, deliberate, uniform black screen
    // instead of an unpredictable flash.
    // ─────────────────────────────────────────────────────────────

    private void showColdStartCover() {
        ensureOverlay();
        syncOverlayToWebViewBounds();
        freezeFrameOverlay.setImageBitmap(null);
        freezeFrameOverlay.setImageDrawable(null);
        freezeFrameOverlay.setBackgroundColor(Color.BLACK);
        freezeFrameOverlay.setVisibility(View.VISIBLE);
        freezeFrameOverlay.bringToFront();
        scheduleColdStartSafetyReveal();
    }

    private void scheduleColdStartSafetyReveal() {
        cancelColdStartSafetyReveal();
        coldStartSafetyRunnable = () -> {
            // Belt-and-braces only: onPageFinished() -> revealWhenRedrawn()
            // should always get there first in practice. This just guarantees
            // a broken asset, a dead network, or a very slow device never
            // leaves someone staring at a permanent black screen.
            Log.w(TAG, "Cold-start cover safety timeout reached — revealing without waiting further.");
            if (freezeFrameOverlay != null) freezeFrameOverlay.setVisibility(View.GONE);
            coldStartSafetyRunnable = null;
        };
        webView.postDelayed(coldStartSafetyRunnable, COLD_START_SAFETY_TIMEOUT_MS);
    }

    private void cancelColdStartSafetyReveal() {
        if (coldStartSafetyRunnable != null) {
            webView.removeCallbacks(coldStartSafetyRunnable);
            coldStartSafetyRunnable = null;
        }
    }

       public boolean onBackPressed() {
        if (bridgeHandler != null && bridgeHandler.isBackpressDisabled()) {
            evaluateJavascript(
                "if(window._CarbonInternal && window._CarbonInternal.triggerBackpress){" +
                "window._CarbonInternal.triggerBackpress();}"
            );
            return true; // consumed — never falls through to app exit
        }

        if (webView.canGoBack()) { webView.goBack(); return true; }
        return false;
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100 && uploadMessageAboveL != null) {
            Uri[] results = (data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            uploadMessageAboveL.onReceiveValue(results);
            uploadMessageAboveL = null;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (bridgeHandler != null) {
            bridgeHandler.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public void onDestroy() {
        if (bridgeHandler != null) {
            bridgeHandler.destroy();
            bridgeHandler = null;
        }
        cancelColdStartSafetyReveal();
        if (revealListener != null) {
            webView.getViewTreeObserver().removeOnPreDrawListener(revealListener);
            revealListener = null;
        }
        if (freezeFrameOverlay != null) {
            ViewGroup overlayParent = (ViewGroup) freezeFrameOverlay.getParent();
            if (overlayParent != null) overlayParent.removeView(freezeFrameOverlay);
            freezeFrameOverlay = null;
        }
        if (cachedSnapshotBuffer != null && !cachedSnapshotBuffer.isRecycled()) {
            cachedSnapshotBuffer.recycle();
            cachedSnapshotBuffer = null;
        }
        webView.loadUrl("about:blank");
        webView.stopLoading();
        webView.setWebChromeClient(null);
        webView.setWebViewClient(null);
        ViewGroup parent = (ViewGroup) webView.getParent();
        if (parent != null) parent.removeView(webView);
        webView.removeAllViews();
        webView.destroy();
        Log.d(TAG, "Engine destroyed.");
    }
}