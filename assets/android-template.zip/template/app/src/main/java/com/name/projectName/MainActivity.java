package {{PACKAGE_NAME}};
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.*;
import androidx.versionedparcelable.*;
import androidx.webkit.*;

import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private MainBinding binding;
	private MainRender renderer;

	// Stays true for the lifetime of the process. Since static fields are
	// wiped when Android kills the process (which is exactly the scenario we
	// need to detect — the app being killed in the background, typically
	// because many other apps were competing for memory), this flag being
	// false the first time onCreate() runs in a process tells us this is
	// either a genuinely fresh launch or a restore from Recents after a kill.
	// Combined with savedInstanceState != null (only set when Android is
	// recreating a previously-existing task, not a first-ever launch), the
	// two together identify "restored after process death" specifically —
	// as opposed to a first launch (savedInstanceState == null) or a
	// same-process recreation such as a rotation (flag already true).
	private static boolean sProcessAlive = false;

	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);

		boolean restoredAfterProcessDeath = (_savedInstanceState != null) && !sProcessAlive;
		sProcessAlive = true;

		if (restoredAfterProcessDeath) {
			// Paint the window itself black as the very first thing our code
			// does, before inflating any layout. This closes the gap between
			// "our onCreate starts running" and "MainRender's black cover
			// overlay is actually attached and composited" a few lines below.
			//
			// It CANNOT reach further back than that: the blank/white flash
			// that shows immediately when Android starts recreating a killed
			// process -- before onCreate() ever runs -- is the OS's own
			// "starting window", painted from the app theme's
			// android:windowBackground (or android:windowSplashScreenBackground
			// on API 31+). No Java code runs early enough to affect that part;
			// it has to be fixed by setting the theme's background to black
			// (or your brand color) in styles.xml/themes.xml.
			getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
		}

		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic(restoredAfterProcessDeath);
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		binding.mainWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	
	private void initializeLogic(boolean restoredAfterProcessDeath) {
		renderer = new MainRender(this, binding.mainWebView, restoredAfterProcessDeath);
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (renderer != null) renderer.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (renderer != null) renderer.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (renderer != null) renderer.onDestroy();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (renderer != null) renderer.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (renderer != null) renderer.onRequestPermissionsResult(requestCode, permissions, grantResults);
	}
	
	@Override
	public void onBackPressed() {
		if (renderer == null || !renderer.onBackPressed()) {
			super.onBackPressed();
		}
	}
}