package {{PACKAGE_NAME}};
import android.app.Activity;
import android.content.Context;

import {{PACKAGE_NAME}}.BaseBridge;
import {{PACKAGE_NAME}}.BridgeHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * FileUtilsBridge — Full async file-system bridge for MyWebEngine
 *
 * ══════════════════════════════════════════════════════════════
 *  TYPE PREFIX (first argument "type"):
 *    "a"  →  assets folder        (read-only, bundled with APK)
 *    "i"  →  internal storage     (app-private, no permissions needed)
 *    "e"  →  external storage     (needs WRITE_EXTERNAL_STORAGE permission)
 *
 *  All file operations are ASYNC — they never freeze the UI.
 * ══════════════════════════════════════════════════════════════
 *
 *  JS USAGE EXAMPLES:
 *
 *    // Read a file from assets
 *    const text = await Android.readFile("a", "data/config.json");
 *
 *    // Write to internal storage
 *    await Android.writeFile("i", "notes.txt", "Hello world");
 *
 *    // Append to a file
 *    await Android.appendFile("i", "log.txt", "New line\n");
 *
 *    // Remove a file
 *    await Android.removeFile("i", "old.txt");
 *
 *    // Check if file/folder exists
 *    const exists = await Android.isExist("i/mydir");
 *
 *    // Get file size in bytes
 *    const size = await Android.fileSize("i/notes.txt");
 *
 *    // List files in a folder (returns JSON array of file info objects)
 *    const files = JSON.parse(await Android.fileList("i", "docs"));
 *
 *    // Rename a file or folder
 *    await Android.fRename("i/old.txt", "i/new.txt");
 *
 * ══════════════════════════════════════════════════════════════
 */
public class FileUtilsBridge extends BaseBridge {

    // ── Action names ──────────────────────────────────────────────
    private static final Set<String> ACTIONS = new HashSet<>(Arrays.asList(
        "fReadFile",          // (type, name)           → file content string
        "fWriteFile",         // (type, name, value)    → "OK"
        "fAppendFile",        // (type, name, value)    → "OK"
        "removeFile",         // (type, name)           → "OK"
        "removeFolder",       // (type, name)           → "OK"
        "isExist",            // (name)                 → "true"/"false"  (type embedded in name e.g. "i/path")
        "fileSize",           // (name)                 → size string in bytes
        "folderSize",         // (name)                 → total size string in bytes
        "fRename",            // (oldPath, newPath)     → "OK"  (type embedded e.g. "i/old")
        "fileList",           // (type, name)           → JSON array of file-info objects
        "folderList",         // (type, name)           → JSON array of folder-info objects
        "fList",              // (type, name)           → JSON array of both files & folders
        "fCreateDetails",     // (name)                 → JSON object with creation info
        "fModifiedDetails",   // (name)                 → JSON object with modified info
        "fPermission"         // (name)                 → JSON object with permission info
    ));

    // All operations are async (file I/O)
    private static final Set<String> ASYNC_ACTIONS = new HashSet<>(ACTIONS);

    private final Activity      activity;
    private final BridgeHandler bridge;

    // Date formatter for file timestamps
    private static final SimpleDateFormat DATE_FMT =
        new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);

    public FileUtilsBridge(Activity activity, BridgeHandler bridge) {
        this.activity = activity;
        this.bridge   = bridge;
    }

    @Override
    public boolean handles(String action) {
        return ACTIONS.contains(action);
    }

    @Override
    public boolean isAsync(String action) {
        return ASYNC_ACTIONS.contains(action);
    }

    @Override
    public String handleSync(String action, String payload) throws Exception {
        throw new UnsupportedOperationException("FileUtilsBridge is fully async");
    }

    // ══════════════════════════════════════════════════════════════
    //  ASYNC HANDLER
    // ══════════════════════════════════════════════════════════════
    @Override
    public void handleAsync(String action, String payload, Callback callback) {
        try {
            if (Thread.currentThread().isInterrupted()) return;

            // All actions receive a JSON payload from JS
            JSONObject args = new JSONObject(payload);

            switch (action) {

                // ── READ ──────────────────────────────────────────────────
                case "fReadFile": {
                    String type = args.getString("type");
                    String name = args.getString("name");
                    callback.resolve(readFileContent(type, name));
                    break;
                }

                // ── WRITE ─────────────────────────────────────────────────
                case "fWriteFile": {
                    String type  = args.getString("type");
                    String name  = args.getString("name");
                    String value = args.getString("value");
                    writeFileContent(type, name, value, false);
                    callback.resolve("OK");
                    break;
                }

                // ── APPEND ────────────────────────────────────────────────
                case "fAppendFile": {
                    String type  = args.getString("type");
                    String name  = args.getString("name");
                    String value = args.getString("value");
                    writeFileContent(type, name, value, true);
                    callback.resolve("OK");
                    break;
                }

                // ── REMOVE FILE ───────────────────────────────────────────
                case "removeFile": {
                    String type = args.getString("type");
                    String name = args.getString("name");
                    File f = resolveFile(type, name);
                    if (f.exists() && f.isFile()) {
                        if (!f.delete()) throw new IOException("Could not delete: " + name);
                    }
                    callback.resolve("OK");
                    break;
                }

                // ── REMOVE FOLDER ─────────────────────────────────────────
                case "removeFolder": {
                    String type = args.getString("type");
                    String name = args.getString("name");
                    File dir = resolveFile(type, name);
                    deleteRecursive(dir);
                    callback.resolve("OK");
                    break;
                }

                // ── IS EXIST ─────────────────────────────────────────────
                // name format: "type/path"  e.g. "i/docs/note.txt"
                case "isExist": {
                    String name = args.getString("name");
                    File f = resolveFromPrefixedPath(name);
                    callback.resolve(String.valueOf(f != null && f.exists()));
                    break;
                }

                // ── FILE SIZE ─────────────────────────────────────────────
                // name format: "type/path"
                case "fileSize": {
                    String name = args.getString("name");
                    File f = resolveFromPrefixedPath(name);
                    if (f == null || !f.exists() || !f.isFile())
                        throw new IOException("File not found: " + name);
                    callback.resolve(String.valueOf(f.length()));
                    break;
                }

                // ── FOLDER SIZE ───────────────────────────────────────────
                case "folderSize": {
                    String name = args.getString("name");
                    File dir = resolveFromPrefixedPath(name);
                    if (dir == null || !dir.exists() || !dir.isDirectory())
                        throw new IOException("Folder not found: " + name);
                    callback.resolve(String.valueOf(dirSize(dir)));
                    break;
                }

                // ── RENAME ────────────────────────────────────────────────
                // oldPath / newPath format: "type/path"
                case "fRename": {
                    String oldPath = args.getString("old");
                    String newPath = args.getString("new");
                    File src = resolveFromPrefixedPath(oldPath);
                    File dst = resolveFromPrefixedPath(newPath);
                    if (src == null || !src.exists())
                        throw new IOException("Source not found: " + oldPath);
                    if (!src.renameTo(dst))
                        throw new IOException("Rename failed: " + oldPath + " → " + newPath);
                    callback.resolve("OK");
                    break;
                }

                // ── FILE LIST ─────────────────────────────────────────────
                case "fileList": {
                    String type = args.getString("type");
                    String name = args.getString("name");
                    File dir = resolveFile(type, name);
                    callback.resolve(listEntries(dir, true, false).toString());
                    break;
                }

                // ── FOLDER LIST ───────────────────────────────────────────
                case "folderList": {
                    String type = args.getString("type");
                    String name = args.getString("name");
                    File dir = resolveFile(type, name);
                    callback.resolve(listEntries(dir, false, true).toString());
                    break;
                }

                // ── FLIST (files + folders) ────────────────────────────────
                case "fList": {
                    String type = args.getString("type");
                    String name = args.getString("name");
                    File dir = resolveFile(type, name);
                    callback.resolve(listEntries(dir, true, true).toString());
                    break;
                }

                // ── CREATE DETAILS ────────────────────────────────────────
                case "fCreateDetails": {
                    String name = args.getString("name");
                    File f = resolveFromPrefixedPath(name);
                    if (f == null || !f.exists())
                        throw new IOException("Not found: " + name);
                    // Android does not expose creationTime via File API;
                    // we return lastModified as a best-effort approximation
                    // (for true creation time, use java.nio on API 26+)
                    JSONObject info = new JSONObject();
                    info.put("name",      f.getName());
                    info.put("path",      f.getAbsolutePath());
                    info.put("createdMs", f.lastModified()); // best approximation
                    info.put("created",   DATE_FMT.format(new Date(f.lastModified())));
                    info.put("isFile",    f.isFile());
                    info.put("isDir",     f.isDirectory());
                    callback.resolve(info.toString());
                    break;
                }

                // ── MODIFIED DETAILS ──────────────────────────────────────
                case "fModifiedDetails": {
                    String name = args.getString("name");
                    File f = resolveFromPrefixedPath(name);
                    if (f == null || !f.exists())
                        throw new IOException("Not found: " + name);
                    JSONObject info = new JSONObject();
                    info.put("name",       f.getName());
                    info.put("path",       f.getAbsolutePath());
                    info.put("modifiedMs", f.lastModified());
                    info.put("modified",   DATE_FMT.format(new Date(f.lastModified())));
                    info.put("isFile",     f.isFile());
                    info.put("isDir",      f.isDirectory());
                    callback.resolve(info.toString());
                    break;
                }

                // ── PERMISSION DETAILS ────────────────────────────────────
                case "fPermission": {
                    String name = args.getString("name");
                    File f = resolveFromPrefixedPath(name);
                    if (f == null || !f.exists())
                        throw new IOException("Not found: " + name);
                    JSONObject info = new JSONObject();
                    info.put("name",     f.getName());
                    info.put("path",     f.getAbsolutePath());
                    info.put("canRead",  f.canRead());
                    info.put("canWrite", f.canWrite());
                    info.put("canExec",  f.canExecute());
                    info.put("hidden",   f.isHidden());
                    callback.resolve(info.toString());
                    break;
                }

                default:
                    callback.reject("Unhandled action: " + action);
            }

        } catch (InterruptedException e) {
            // Cancelled — stop silently
        } catch (Exception e) {
            callback.reject(e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════

    /**
     * Resolve a (type, name) pair to a File.
     *   "a" → assets  (returns a marker file object; actual reading uses AssetManager)
     *   "i" → internal files dir
     *   "e" → external files dir (first external, falls back to internal if null)
     */
    private File resolveFile(String type, String name) throws IOException {
        switch (type) {
            case "a":
                // Assets are read-only — return a dummy path for write guards
                return new File("ASSETS_READONLY/" + name);
            case "i":
                return new File(activity.getFilesDir(), name);
            case "e":
                File extDir = activity.getExternalFilesDir(null);
                if (extDir == null) extDir = activity.getFilesDir(); // fallback
                return new File(extDir, name);
            default:
                throw new IllegalArgumentException("Unknown storage type: " + type);
        }
    }

    /**
     * Resolve a prefixed path of the form "type/relative/path" to a File.
     * e.g. "i/notes/todo.txt" → internal files dir + "notes/todo.txt"
     */
    private File resolveFromPrefixedPath(String prefixedName) throws IOException {
        if (prefixedName == null || prefixedName.length() < 2) return null;
        int slash = prefixedName.indexOf('/');
        if (slash < 0) {
            // No slash — treat the single char as type, empty name
            return resolveFile(prefixedName, "");
        }
        String type = prefixedName.substring(0, slash);
        String name = prefixedName.substring(slash + 1);
        return resolveFile(type, name);
    }

    // ── Read ──────────────────────────────────────────────────────

    private String readFileContent(String type, String name) throws IOException {
        if ("a".equals(type)) {
            // Read from assets using AssetManager
            InputStream is = activity.getAssets().open(name);
            return streamToString(is);
        }
        File f = resolveFile(type, name);
        if (!f.exists()) throw new IOException("File not found: " + name);
        InputStream is = new FileInputStream(f);
        return streamToString(is);
    }

    private static String streamToString(InputStream is) throws IOException {
        try {
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            // Trim the trailing newline added by readLine loop
            if (sb.length() > 0 && sb.charAt(sb.length() - 1) == '\n') {
                sb.setLength(sb.length() - 1);
            }
            return sb.toString();
        } finally {
            try { is.close(); } catch (IOException ignored) {}
        }
    }

    // ── Write / Append ────────────────────────────────────────────

    private void writeFileContent(String type, String name, String value, boolean append)
            throws IOException {
        if ("a".equals(type)) throw new IOException("Assets folder is read-only");
        File f = resolveFile(type, name);
        // Ensure parent directory exists
        File parent = f.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (OutputStreamWriter writer = new OutputStreamWriter(
                new FileOutputStream(f, append), StandardCharsets.UTF_8)) {
            writer.write(value);
        }
    }

    // ── Delete ────────────────────────────────────────────────────

    private void deleteRecursive(File f) throws IOException {
        if (!f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        if (!f.delete()) throw new IOException("Could not delete: " + f.getAbsolutePath());
    }

    // ── Listing ───────────────────────────────────────────────────

    /**
     * Build a JSON array of top-level entries in dir.
     * includeFiles  → include plain files
     * includeDirs   → include sub-directories (non-recursive)
     */
    private JSONArray listEntries(File dir, boolean includeFiles, boolean includeDirs)
            throws Exception {
        if (!dir.exists() || !dir.isDirectory())
            throw new IOException("Not a directory: " + dir.getAbsolutePath());

        JSONArray result = new JSONArray();
        File[] entries = dir.listFiles();
        if (entries == null) return result;

        for (File entry : entries) {
            if (Thread.currentThread().isInterrupted()) break;
            boolean isDir  = entry.isDirectory();
            boolean isFile = entry.isFile();
            if (isDir  && !includeDirs)  continue;
            if (isFile && !includeFiles) continue;

            JSONObject info = new JSONObject();
            info.put("name",       entry.getName());
            info.put("path",       entry.getAbsolutePath());
            info.put("isFile",     isFile);
            info.put("isDir",      isDir);
            info.put("size",       isFile ? entry.length() : dirSize(entry));
            info.put("modifiedMs", entry.lastModified());
            info.put("modified",   DATE_FMT.format(new Date(entry.lastModified())));
            info.put("canRead",    entry.canRead());
            info.put("canWrite",   entry.canWrite());
            result.put(info);
        }
        return result;
    }

    // ── Size ──────────────────────────────────────────────────────

    /** Recursively calculate directory size in bytes. */
    private long dirSize(File dir) {
        if (dir.isFile()) return dir.length();
        long total = 0;
        File[] children = dir.listFiles();
        if (children != null) {
            for (File child : children) {
                total += dirSize(child);
            }
        }
        return total;
    }
}