package {{PACKAGE_NAME}};

import android.app.Activity;
import {{PACKAGE_NAME}}.BaseBridge;
import {{PACKAGE_NAME}}.BridgeHandler;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * ExampleCustomBridge — Copy-paste template for a new bridge
 *
 * ──────────────────────────────────────────────────────────────
 *  STEPS TO CREATE A NEW BRIDGE:
 *
 *   1. Copy this file  →  CoreBridges/YourFeatureBridge.java
 *   2. Rename the class and update the package import
 *   3. Fill in ACTIONS with your action names
 *   4. Implement handleSync() and/or handleAsync()
 *   5. In BridgeHandler.java constructor, add:
 *         register(new YourFeatureBridge(activity, this));
 *   6. Done — JS can now call Android.yourAction(payload)
 * ──────────────────────────────────────────────────────────────
 *
 *  JS USAGE AFTER REGISTRATION:
 *
 *    // Sync action
 *    const result = await Android.greetUser("World");
 *    console.log(result); // "Hello, World!"
 *
 *    // Async action
 *    const data = await Android.fetchSomething("param");
 *
 *    // Error handling
 *    try {
 *      const r = await Android.riskyAction("input");
 *    } catch (err) {
 *      console.error("Native error:", err);
 *    }
 * ──────────────────────────────────────────────────────────────
 */
public class ExampleCustomBridge extends BaseBridge {

    // ── 1. Declare the action names this bridge handles ───────────
    private static final Set<String> ACTIONS = new HashSet<>(Arrays.asList(
        "greetUser",        // sync example
        "fetchSomething"    // async example
        // Add more action strings here ↓
    ));

    private final Activity      activity;
    private final BridgeHandler bridge;  // gives access to permissions, QuickJS, assets…

    public ExampleCustomBridge(Activity activity, BridgeHandler bridge) {
        this.activity = activity;
        this.bridge   = bridge;
    }

    // ── 2. Tell the router which actions belong to this bridge ────
    @Override
    public boolean handles(String action) {
        return ACTIONS.contains(action);
    }

    // ── 3. Mark which actions need the async / callback pattern ──
    @Override
    public boolean isAsync(String action) {
        return "fetchSomething".equals(action); // only this one is async
    }

    // ── 4a. SYNC handler — return result immediately ──────────────
    @Override
    public String handleSync(String action, String payload) throws Exception {
        switch (action) {

            case "greetUser":
                return "Hello, " + payload + "!";

            // Add more sync cases here ↓

            default:
                throw new UnsupportedOperationException("Unhandled: " + action);
        }
    }

    // ── 4b. ASYNC handler — call callback when done ───────────────
    @Override
    public void handleAsync(String action, String payload, Callback callback) {
        switch (action) {

            case "fetchSomething":
                try {
                    // Simulate work (replace with real I/O, network, etc.)
                    Thread.sleep(200);
                    if (Thread.currentThread().isInterrupted()) return;
                    callback.resolve("Result for: " + payload);
                } catch (InterruptedException e) {
                    // Task was cancelled by JS — just stop silently
                } catch (Exception e) {
                    callback.reject(e.getMessage());
                }
                break;

            // Add more async cases here ↓

            default:
                callback.reject("Unhandled async action: " + action);
        }
    }
}
