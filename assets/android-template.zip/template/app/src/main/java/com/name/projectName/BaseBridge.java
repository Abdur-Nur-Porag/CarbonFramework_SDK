package {{PACKAGE_NAME}};

/**
 * BaseBridge — Contract for all CoreBridges
 *
 * Every bridge you create inside CoreBridges/ must extend this class.
 *
 * ══════════════════════════════════════════════════════════════
 *  QUICK GUIDE
 * ══════════════════════════════════════════════════════════════
 *
 *  1. Declare which actions your bridge owns  →  handles(action)
 *  2. Mark which of those are async           →  isAsync(action)
 *  3. Implement sync logic                    →  handleSync()
 *  4. Implement async logic                   →  handleAsync()
 *
 *  SYNC  — return a String result.  Fast (< a few ms), no blocking I/O.
 *  ASYNC — call callback.resolve(result) or callback.reject(error)
 *          from whatever thread you want, whenever you are done.
 *
 * ══════════════════════════════════════════════════════════════
 *  MINIMAL EXAMPLE
 * ══════════════════════════════════════════════════════════════
 *
 *  public class GreetBridge extends BaseBridge {
 *
 *      @Override public boolean handles(String action) {
 *          return "greet".equals(action);
 *      }
 *
 *      @Override public boolean isAsync(String action) {
 *          return false;   // sync is fine for a simple greeting
 *      }
 *
 *      @Override public String handleSync(String action, String payload) {
 *          return "Hello, " + payload + "!";
 *      }
 *  }
 *
 *  Then in BridgeHandler constructor:
 *      register(new GreetBridge());
 *
 * ══════════════════════════════════════════════════════════════
 */
public abstract class BaseBridge {

    // ─── Routing ─────────────────────────────────────────────────

    /**
     * Return true if this bridge knows how to handle the given action name.
     * Called on every incoming bridge request — keep it O(1).
     */
    public abstract boolean handles(String action);

    /**
     * Return true if this action requires a background thread / callback pattern.
     * Return false if handleSync() can answer immediately.
     *
     * Default: false (sync).  Override only the actions that truly need async.
     */
    public boolean isAsync(String action) {
        return false;
    }

    // ─── Sync handler ────────────────────────────────────────────

    /**
     * Execute a synchronous action and return the result string.
     * Return "OK" for fire-and-forget actions.
     * Throw any Exception to send an error back to the JS .catch() handler.
     */
    public String handleSync(String action, String payload) throws Exception {
        return "OK";
    }

    // ─── Async handler ───────────────────────────────────────────

    /**
     * Execute an asynchronous action.
     * When work is done (on any thread) call callback.resolve(result)
     * or callback.reject(errorMessage).
     * If the thread is interrupted, stop work and let the thread die quietly.
     */
    public void handleAsync(String action, String payload, Callback callback) {
        callback.reject("NOT_IMPLEMENTED");
    }

    // ─── Callback contract ───────────────────────────────────────

    public interface Callback {
        /** Call with the result string to resolve the JS Promise. */
        void resolve(String result);
        /** Call with an error message to reject the JS Promise. */
        void reject(String error);
    }
}
