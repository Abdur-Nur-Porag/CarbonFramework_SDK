package {{PACKAGE_NAME}};
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

// ── NEW ENGINE ──────────────────────────────────────────────────────────────
// Replaces: import app.cash.quickjs.QuickJs;   (abandoned 2021)
// Library : io.github.taoweiji.quickjs:quickjs-android (Maven Central)
// Gradle  : implementation 'io.github.taoweiji.quickjs:quickjs-android:1.4.6'
//
// THREAD SAFETY: JSContext has a ThreadChecker — it must be used on the same
// thread it was created on. Since evaluateQuickJS() is called from background
// threads, we use createRuntimeWithEventQueue() which gives the runtime its
// own internal event queue thread, making cross-thread calls safe.
import com.quickjs.JSContext;
import com.quickjs.QuickJS;
// ────────────────────────────────────────────────────────────────────────────

import {{PACKAGE_NAME}}.CoreBridges.CoreBridges;
import {{PACKAGE_NAME}}.CoreBridges.FileUtilsBridge;
/**
 * BridgeHandler — Bridge Registry & Core Infrastructure
 *
 * ┌─────────────────────────────────────────────────────────────┐
 * │  This class is NOT where you write bridge logic.            │
 * │  It is the ROUTER that connects JS to your CoreBridges.     │
 * │                                                             │
 * │  To add a new bridge:                                       │
 * │   1. Create  CoreBridges/MyBridge.java                      │
 * │   2. Implement BaseBridge                                   │
 * │   3. Register it here with register(new MyBridge(activity)) │
 * └─────────────────────────────────────────────────────────────┘
 *
 *  ═══ SYNCHRONOUS vs ASYNCHRONOUS ══════════════════════════════
 *
 *  SYNC  — The bridge's handleSync() returns a String immediately.
 *           Used for fast operations: clipboard, toast, prefs, flags.
 *           Runs on the same background thread, must be thread-safe.
 *
 *  ASYNC — The bridge's handleAsync() is called on a dedicated thread.
 *           It receives a Callback to call when work is done.
 *           Used for file I/O, JS engine, network, heavy computation.
 *           The JS side receives a Promise that resolves/rejects.
 *
 *  ═══ PERMISSION HELPER ════════════════════════════════════════
 *
 *  Call requestPermission(name, callback) from any bridge.
 *  Result is delivered via onRequestPermissionsResult().
 *
 *  ═══ JS ENGINE ════════════════════════════════════════════════
 *
 *  Call evaluateQuickJS(script) to run JS in the isolated engine.
 *  Backed by taoweiji/quickjs-android (QuickJS + JSContext).
 */
public class BridgeHandler {

    private final Activity activity;

    // ── JS Engine (taoweiji/quickjs-android) ────────────────────
    // createRuntimeWithEventQueue() gives the runtime its own thread,
    // so JSContext can safely be called from any background thread.
    private QuickJS quickJS;
    private JSContext jsContext;

    // ─── Registry ───────────────────────────────────────────────
    private final List<BaseBridge> bridges = new ArrayList<>();

    // ─── Async task manager ─────────────────────────────────────
    // Bounded pool: max 6 threads, 60 s keep-alive, queue up to 64 tasks.
    // Prevents unbounded thread creation under rapid JS calls.
    private final ExecutorService executor = new ThreadPoolExecutor(
            2, 6, 60L, TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(64),
            new ThreadPoolExecutor.CallerRunsPolicy()
    );
    private final ConcurrentHashMap<String, Thread> activeTasks = new ConcurrentHashMap<>();

    // ─── JS engine reset guard ───────────────────────────────────
    // Prevents two simultaneous failures from double-closing the engine.
    private final AtomicBoolean engineResetting = new AtomicBoolean(false);

    // ─── Permission callbacks ────────────────────────────────────
    private final ConcurrentHashMap<String, PermissionCallback> permissionCallbacks
            = new ConcurrentHashMap<>();
    private static final int PERM_REQUEST_CODE = 101;

    // ─── Back-press state ────────────────────────────────────────
    private boolean isBackpressDisabled = false;

    private static final String TAG = "BridgeHandler";

    // ─────────────────────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────

    public BridgeHandler(Activity activity) {
        this.activity = activity;

        // Boot isolated JS engine
        initJsEngine();

        // ─── Register built-in bridges ──────────────────────────
        // ADD YOUR OWN BELOW  ↓  (one line per bridge)
        register(new CoreBridges.SystemBridge(activity, this));
        register(new CoreBridges.StorageBridge(activity));
        register(new CoreBridges.UiBridge(activity, this));
        register(new CoreBridges.BackpressBridge(activity, this));
        register(new CoreBridges.QuickJsBridge(this));
        register(new FileUtilsBridge(activity, this));
        // register(new CoreBridges.YourNewBridge(activity, this));
    }

    // ─────────────────────────────────────────────────────────────
    // JS ENGINE INIT / RESET
    // ─────────────────────────────────────────────────────────────

    private void initJsEngine() {
        try {
            // createRuntimeWithEventQueue() spins up an internal event-queue
            // thread owned by the runtime — JSContext calls are dispatched to
            // that thread automatically, so calling evaluateQuickJS() from any
            // background thread is safe (no ThreadChecker crash).
            quickJS   = QuickJS.createRuntimeWithEventQueue();
            jsContext = quickJS.createContext();
            Log.d(TAG, "JS engine (taoweiji/quickjs) initialized.");
        } catch (Exception e) {
            Log.e(TAG, "JS engine init failed: ", e);
        }
    }

    /** Tears down the current engine and creates a fresh one.
     *  AtomicBoolean guard ensures only one thread resets at a time —
     *  concurrent failures won't double-close or double-init the engine. */
    private void resetJsEngine() {
        if (!engineResetting.compareAndSet(false, true)) {
            return; // another thread is already resetting — skip
        }
        try {
            try { if (jsContext != null) jsContext.close(); } catch (Exception ignored) {}
            try { if (quickJS   != null) quickJS.close();   } catch (Exception ignored) {}
            jsContext = null;
            quickJS   = null;
            initJsEngine();
        } finally {
            engineResetting.set(false);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // BRIDGE REGISTRY
    // ─────────────────────────────────────────────────────────────

    /** Register a CoreBridge so its actions become available to JS. */
    public void register(BaseBridge bridge) {
        bridges.add(bridge);
        Log.d(TAG, "Bridge registered: " + bridge.getClass().getSimpleName());
    }

    // ─────────────────────────────────────────────────────────────
    // ASYNC EXECUTOR  (called by MainRender on every bridge_req)
    // ─────────────────────────────────────────────────────────────

    /**
     * Routes an action to the correct bridge on a background thread.
     * The bridge either returns synchronously or calls callback.resolve/reject.
     */
    public void executeAsync(String action, String payload, String reqId, MainRender renderer) {
        Thread taskThread = new Thread(() -> {
            try {
                if (Thread.currentThread().isInterrupted()) return;

                // ── Find the bridge that handles this action ──
                BaseBridge handler = findBridge(action);

                if (handler == null) {
                    renderer.completeRequest(reqId,
                            "UNKNOWN_ACTION: No bridge handles '" + action + "'", true);
                    return;
                }

                if (handler.isAsync(action)) {
                    // ── ASYNC path: bridge calls callback itself ──
                    handler.handleAsync(action, payload, new BaseBridge.Callback() {
                        @Override public void resolve(String result) {
                            if (!Thread.currentThread().isInterrupted()) {
                                renderer.completeRequest(reqId, result, false);
                            }
                        }
                        @Override public void reject(String error) {
                            renderer.completeRequest(reqId, error, true);
                        }
                    });
                } else {
                    // ── SYNC path: bridge returns result immediately ──
                    String result = handler.handleSync(action, payload);
                    if (!Thread.currentThread().isInterrupted()) {
                        renderer.completeRequest(reqId, result, false);
                    }
                }

            } catch (InterruptedException e) {
                Log.d(TAG, "Task " + reqId + " cancelled.");
                renderer.completeRequest(reqId, "Task cancelled", true);
            } catch (Exception e) {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                renderer.completeRequest(reqId,
                        e.getClass().getSimpleName() + ": " + e.getMessage() + "\n" + sw, true);
            } finally {
                activeTasks.remove(reqId);
            }
        });

        activeTasks.put(reqId, taskThread);
        // Submit to bounded pool instead of spawning a raw thread.
        // CallerRunsPolicy handles the rare case of a full queue gracefully.
        executor.submit(taskThread);
    }

    /** Interrupts a running async task by its request ID. */
    public void stopTask(String reqId) {
        Thread t = activeTasks.get(reqId);
        if (t != null) {
            t.interrupt();
            activeTasks.remove(reqId);
            Log.d(TAG, "Interrupted task: " + reqId);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // HELPERS  (used by bridges)
    // ─────────────────────────────────────────────────────────────

    public Activity getActivity() { return activity; }

    /**
     * Evaluate a JS script in the isolated engine and return the
     * result as a String.
     *
     * Thread safety: handled internally by the EventQueue thread that
     * createRuntimeWithEventQueue() owns — no external synchronization needed.
     *
     * Previously: quickJs.evaluate(script)              [app.cash.quickjs]
     * Now       : jsContext.executeStringScript(s, f)   [taoweiji/quickjs-android]
     */
    public String evaluateQuickJS(String script) {
        if (jsContext == null) return "ERROR:EngineOffline";
        try {
            String result = jsContext.executeStringScript(script, "<eval>");
            return result != null ? result : "undefined";
        } catch (Exception e) {
            // Fatal engine error — tear down and boot a fresh instance so
            // subsequent calls keep working (same behaviour as old engine).
            Log.w(TAG, "JS engine error (will reset): " + e.getMessage());
            try { resetJsEngine(); } catch (Exception reinitEx) {
                Log.e(TAG, "JS engine re-init failed: " + reinitEx.getMessage());
            }
            return "ERROR:" + e.getMessage();
        }
    }

    public String readFileFromAsset(String fileName) {
        StringBuilder sb = new StringBuilder();
        try (InputStream in = activity.getAssets().open(fileName);
             BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
        } catch (Exception e) {
            Log.e(TAG, "Asset read error [" + fileName + "]: " + e.getMessage());
            return "ERROR";
        }
        return sb.toString();
    }

    // ─── Permission system ───────────────────────────────────────

    public interface PermissionCallback {
        void onResult(boolean granted);
    }

    /**
     * Request a runtime permission. Result is delivered to callback.
     * Use the friendly name: "camera", "mic", "storage", "location"
     */
    public void requestPermission(String name, PermissionCallback callback) {
        String manifest = toManifestPermission(name);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || ContextCompat.checkSelfPermission(activity, manifest)
                   == PackageManager.PERMISSION_GRANTED) {
            if (callback != null) callback.onResult(true);
            return;
        }
        if (callback != null) {
            permissionCallbacks.put(manifest, callback);
        }
        ActivityCompat.requestPermissions(activity, new String[]{manifest}, PERM_REQUEST_CODE);
    }

    public boolean checkPermission(String name) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        try {
            return ContextCompat.checkSelfPermission(activity, toManifestPermission(name))
                   == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) { return false; }
    }

    /** Called by MainActivity.onRequestPermissionsResult */
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode != PERM_REQUEST_CODE) return;
        for (int i = 0; i < permissions.length; i++) {
            PermissionCallback cb = permissionCallbacks.remove(permissions[i]);
            if (cb != null) cb.onResult(grantResults[i] == PackageManager.PERMISSION_GRANTED);
        }
    }

    public String toManifestPermission(String name) {
        switch (name.toLowerCase()) {
            case "camera":          return android.Manifest.permission.CAMERA;
            case "mic":
            case "record_audio":    return android.Manifest.permission.RECORD_AUDIO;
            case "storage":         return android.Manifest.permission.READ_EXTERNAL_STORAGE;
            case "location":        return android.Manifest.permission.ACCESS_FINE_LOCATION;
            case "location_coarse": return android.Manifest.permission.ACCESS_COARSE_LOCATION;
            case "contacts":        return android.Manifest.permission.READ_CONTACTS;
            case "phone":           return android.Manifest.permission.READ_PHONE_STATE;
            default:                return name;
        }
    }

    // ─── Back-press flag ─────────────────────────────────────────

    public boolean isBackpressDisabled() { return isBackpressDisabled; }
    public void setBackpressDisabled(boolean val) { isBackpressDisabled = val; }

    // ─────────────────────────────────────────────────────────────
    // INTERNAL
    // ─────────────────────────────────────────────────────────────

    private BaseBridge findBridge(String action) {
        for (BaseBridge b : bridges) {
            if (b.handles(action)) return b;
        }
        return null;
    }

    /** Returns the registered BackpressBridge so MainRender can forward back-press events. */
    public CoreBridges.BackpressBridge getBackpressBridge() {
        for (BaseBridge b : bridges) {
            if (b instanceof CoreBridges.BackpressBridge) {
                return (CoreBridges.BackpressBridge) b;
            }
        }
        return null;
    }

    /** Cleans up all threads and closes the JS engine. Call from MainRender.onDestroy(). */
    public void destroy() {
        executor.shutdownNow(); // cancel queued + interrupt running tasks
        for (Thread t : activeTasks.values()) t.interrupt();
        activeTasks.clear();

        try { if (jsContext != null) jsContext.close(); } catch (Exception ignored) {}
        try { if (quickJS   != null) quickJS.close();   } catch (Exception ignored) {}
        jsContext = null;
        quickJS   = null;
        Log.d(TAG, "BridgeHandler destroyed.");
    }
}